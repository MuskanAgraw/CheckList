# ChecklistAppMVC
to do list using MVC in iOS

Functionaliy to add, edit and delete items on a to-do list. 

This is also designed using the MVC design pattern.
